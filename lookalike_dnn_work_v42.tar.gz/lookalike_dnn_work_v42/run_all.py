#!/usr/bin env python

import os

### Config 
CONFIG_PS_HOST_START = 18000
CONFIG_WORKER_HOST_START = 19000

os.system("export HADOOP_USER_NAME=xpguo")
ps_hosts="10.21.10.13"
worker_hosts="10.21.10.13,10.21.10.14,10.21.10.15,10.21.10.16,10.21.10.17"
ps_num=1
worker_num=5

local_host = os.popen('hostname -i', 'r').read().strip()
print("local_host = %s" % local_host)

ps_init_host_list = ps_hosts.split(",")
worker_init_host_list = worker_hosts.split(",")

ps_host_list = []
for i in range(ps_num):
    tmp_host = ps_init_host_list[i % len(ps_init_host_list)]
    tmp_port = str(i / len(ps_init_host_list) + CONFIG_PS_HOST_START)
    ps_host_list.append(tmp_host + ":" + tmp_port)
print("ps host list :")
print(",".join(ps_host_list))

    
worker_host_list = []
for i in range(worker_num):
    tmp_host = worker_init_host_list[i % len(worker_init_host_list)]
    tmp_port = str(i / len(worker_init_host_list) + CONFIG_WORKER_HOST_START)
    worker_host_list.append(tmp_host + ":" + tmp_port)
print("worker host list :")
print(",".join(worker_host_list))

print("=====================================================================")

for i in range(len(ps_host_list)):
    ps_host = ps_host_list[i]
    if ps_host.split(":")[0] == local_host:
        #print(ps_host)
        run_commend = "bash run.sh %s %s %s %d %d %d" % (",".join(ps_host_list), ",".join(worker_host_list), "ps", i, ps_num, worker_num)
        print("run_commend = " + run_commend)
        run_status = os.system("nohup %s > run_ps_%d.log 2>&1 &" % (run_commend, i))
        print("run_status = %d" % run_status)
       

for i in range(len(worker_host_list)):
    worker_host = worker_host_list[i] 
    if worker_host.split(":")[0] == local_host:
        #print(worker_host)
        run_commend = "bash run.sh %s %s %s %d %d %d" % (",".join(ps_host_list), ",".join(worker_host_list), "worker", i, ps_num, worker_num)
        print("run_commend = " + run_commend)
        run_status = os.system("nohup %s > run_worker_%d.log 2>&1 &" % (run_commend, i))
        print("run_status = %d" % run_status)

