cat t_td_lookalike_test_data_with_features_group_spark | awk -F"," '{ print $50","$2 }' > t_td_lookalike_test_data_with_features_group_spark.aid_uid
paste -d, t_td_lookalike_test_data_with_features_group_spark.aid_uid predict.data > submission.csv.1
sed -i "1iaid,uid,score" submission.csv.1
cat submission.csv.1 | head -n 2265990 > submission.csv
