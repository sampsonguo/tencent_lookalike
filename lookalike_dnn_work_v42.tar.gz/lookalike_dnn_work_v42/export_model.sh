#!/bin/bash

# source ~/.bashrc

export HADOOP_USER_NAME="xpguo"

#model_dir="hdfs://footstone/data/project/dataming/contentrec/lookalike/tensorflow/model/20180427_v2"
model_dir="hdfs://footstone/data/project/dataming/contentrec/lookalike/tensorflow/model/20180430_v2"

python MWdnn.py \
    --run_mode "local" \
    --job_type "export_savedmodel" \
    --model_type "deep" \
    --model_dir "${model_dir}" \
    --export_savedmodel "./export_model" \
    --savedmodel_mode parsing \
    --feature_size 1000000
echo "run task finished"

