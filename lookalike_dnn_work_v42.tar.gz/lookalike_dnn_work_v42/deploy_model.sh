
#cd to current folder
#cd "$(dirname "$0")"

/home/xpguo/push_dnn_serving/tensorflow_model_server_1.4_gcc_hdfs \
    --port=8600 \
    --model_name=wnd-game-rec \
    --model_base_path=/home/xpguo/lookalike_dnn_serving/export_model > ./tensorflow.log 2>&1 &
