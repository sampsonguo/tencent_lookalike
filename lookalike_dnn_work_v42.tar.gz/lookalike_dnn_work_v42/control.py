from fabric.api import env
from fabric.api import cd
from fabric.api import run
from fabric.api import local
from fabric.api import get
from fabric.api import put
from fabric.api import settings
from fabric.api import parallel
from fabric.api import hide
from fabric.api import execute

version = "v42"
env.user = 'root'
env.password = 'Vivo@2016--'
env.hosts = ["10.21.10." + str(i) for i in list(range(13, 18))]
remote_dir="/home/xpguo/lookalike/lookalike_dnn_online_" + version
local_dir="/home/xpguo/lookalike/lookalike_dnn_work_" + version
files_to_copy=["MWdnn.py", "run.sh", "run_all.py"]

serving_remote_dir="/home/xpguo/lookalike/lookalike_dnn_serving_" + version
serving_local_dir="/home/xpguo/lookalike/lookalike_dnn_work_" + version + "/export_model"
serving_folder_to_copy=["export_model"]
serving_files_to_copy=["tensorflow_model_server_1.4_gcc_hdfs", "deploy_model.sh"]

@parallel
def scp_data():
    with hide('running', 'output'), settings(warn_only=True):
        run("rm -rf " + remote_dir)
        run("mkdir -p " + remote_dir)
    for file_name in files_to_copy:
        put(local_dir + "/" + file_name, remote_dir)

@parallel
def get_IP():
    with hide('running', 'output'), settings(warn_only=True):
        ip_1=run("echo $SSH_CONNECTION|awk '{print $3}'")
        ip_2=run("hostname -i")
        if ip_1!=ip_2:
            print(ip_1+" : "+ip_2)


@parallel
def run_process():
    with settings(warn_only=True), cd(remote_dir):
        run('nohup python run_all.py > run_all.$(date +"%Y-%m-%d-%H-%M").log 2>&1 &',pty=False)

@parallel
def get_status():
    with hide('running', 'output'), settings(warn_only=True):
        ip=run("hostname -i|awk '{print $NF}'")
        worker_num=run("top -b -n1 | grep python | wc -l | awk '{print}'")
        cpu_usage=run("top -b -n 1 | grep python | awk 'BEGIN{cpu=0}{cpu+=$9}END{print cpu}'")
        if(int(worker_num) > 0):
            print(ip+" : worker_number "+worker_num+" cpu_usage "+cpu_usage+"%")

@parallel
def shutdown_process():
    with settings(warn_only=True):
        #run("pkill python")
        run("ps aux | grep MWdnn.py | grep lookalike | awk '{print $2}'|xargs kill -9")

@parallel
def scp_model_file():
    with hide('running', 'output'), settings(warn_only=True):
        run("rm -rf " + serving_remote_dir)
        run("mkdir -p " + serving_remote_dir)
        put(serving_local_dir, serving_remote_dir)
        for file_name in serving_files_to_copy:
            put(local_dir + "/" + file_name, serving_remote_dir)


@parallel
def deploy_model():
    with settings(warn_only=True), cd(serving_remote_dir):
        run('chmod a+x tensorflow_model_server_1.4_gcc_hdfs', pty=False)
        run('nohup sh -x deploy_model.sh > deploy_model.$(date +"%Y-%m-%d-%H-%M").log 2>&1 &', pty=False)

def stop():
    execute(shutdown_process)

def start():
    execute(scp_data)
    execute(get_IP)
    execute(get_status)
    print("run_process")
    execute(run_process)
    execute(get_status)
    #execute(scp_model_file)
    #execute(deploy_model) 

if __name__ == "__main__":
    print("hosts:" + (",".join(env.hosts)))
    print("remote_dir : " + remote_dir)
    print("local_dir : " + local_dir)
    print("files_to_copy : " + (",".join(files_to_copy)))
    
    start()
    #stop()    
