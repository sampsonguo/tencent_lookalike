#!/bin/bash

# source ~/.bashrc

export HADOOP_USER_NAME="xpguo"

model_dir="hdfs://footstone/data/project/dataming/contentrec/lookalike/tensorflow/model/20180511_v28_v9"

python MWdnn.py \
    --run_mode "local" \
    --job_type "predict" \
    --model_type "wide_and_deep" \
    --model_dir "${model_dir}" \
    --eval_data "./t_td_lookalike_test_data_with_features_group_spark" \
    --feature_size 1000000 \
    --eval_ckpt_id 0
echo "run task finished"

