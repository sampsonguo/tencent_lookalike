#!/bin/bash

# source ~/.bashrc

# config
model_dir="hdfs://footstone/data/project/dataming/contentrec/lookalike/tensorflow/model/20180523_v42_v10"
train_data="hdfs://footstone/hive/warehouse/dm_push_dev.db/t_td_lookalike_train_data_with_features_group_spark_train_99"
eval_data="hdfs://footstone/hive/warehouse/dm_push_dev.db/t_td_lookalike_train_data_with_features_group_spark_valid_01"
config_model_type="wide_and_deep"

## get input parameter
ps_hosts=$1
worker_hosts=$2
task_type=$3
task_index=$4
ps_num=$5
worker_num=$6

echo "[MYLOG]ps_host is ${ps_hosts}"
echo "[MYLOG]worker_host is ${worker_hosts}"
echo "[MYLOG]task_type is ${task_type}"
echo "[MYLOG]task_index is ${task_index}"
echo "[MYLOG]ps_num is ${ps_num}"
echo "[MYLOG]worker_num is ${worker_num}"

begin_time=$(date +"%Y-%m-%d %H:%M:%S")
feature_size=1000000

now="$(date +'%Y%m%d_%H%M')"

echo "[MYLOG]job begin at ${begin_time}..."

export HADOOP_USER_NAME="xpguo"
export CLASSPATH=$CLASSPATH:$(${HADOOP_HDFS_HOME}/bin/hadoop classpath --glob)

function print() {
    local msg="$@"
    local prefix=$(date +"%Y-%m-%d %H:%M:%S")
    echo -e "\e[032m[${prefix}][INFO] ${msg}\e[0m"
}

function check_return() {
    local ret=$1
    local prefix=$(date +"%Y-%m-%d %H:%M:%S")
    if [[ ${ret} -eq 0 ]]; then
        echo -e "\e[032m[${prefix}][INFO] success\e[0m"
    else
        echo -e "\e[031m[${prefix}][ERROR] failed\e[0m"
        exit ${ret}
    fi
    return ${ret}
}

function get_train_data() {
    echo "here"
}

function distribute_files() {

    local train_files=($(hadoop fs -ls -R ${train_data} | awk -F ' ' '{if(NF == 8 && $5 > 0) print $8}'))
    local eval_files=($(hadoop fs -ls -R ${eval_data} | awk -F ' ' '{if(NF == 8 && $5 > 0) print $8}'))
    
    print "there are ${#train_files[@]} files in ${train_data}"
    print "there are ${#eval_files[@]} files in ${eval_data}"

    if [[ ${#train_files[@]} -lt ${worker_num} ]]; then
        print "worker num must be not greater than train files num"
        check_return 1
    fi

    if [[ ${#eval_files[@]} -lt ${worker_num} ]]; then
        print "worker num must be not greater than eval files num"
        check_return 2
    fi

    set +x
    for ((i=0; i<${#train_files[@]}; ++i)); do
        let j=i%${worker_num}
        if [[ ${i} -lt ${worker_num} ]]; then
            train_data_list[j]="${train_files[$i]}"
        else
            train_data_list[j]="${train_data_list[$j]},${train_files[$i]}"
        fi
    done
    for ((i=0; i<${#eval_files[@]}; ++i)); do
        let j=i%${worker_num}
        if [[ ${i} -lt ${worker_num} ]]; then
            eval_data_list[j]="${eval_files[$i]}"
        else
            eval_data_list[j]="${eval_data_list[$j]},${eval_files[$i]}"
        fi
    done
    set -x
  
    check_return $?
}

function run_task() {
    local task_type=$1
    local task_index=$2
    
    echo "run task begin..."
    python MWdnn.py \
        --run_mode "distributed" \
        --job_type "train_and_eval" \
        --model_type "${config_model_type}" \
        --model_dir "${model_dir}" \
        --feature_size ${feature_size} \
        --cold_start False \
        --train_data "${train_data_list[${task_index}]}" \
        --eval_data "${eval_data_list[${task_index}]}" \
        --worker_hosts "${worker_hosts}" \
        --ps_hosts "${ps_hosts}" \
        --task_type "${task_type}" \
        --task_index ${task_index}
    echo "run task finished"

    local ret=$?
    return ${ret}
}

if [[ "${task_type}" == "worker" ]]; then
    print "${worker_num} worker tasks will start..."
    get_train_data
    distribute_files ${task_type}
    run_task ${task_type} ${task_index}
elif [[ "${task_type}" == "ps" ]]; then
    print "${ps_num} ps tasks will start..."
    get_train_data
    distribute_files ${task_type}
    run_task ${task_type} ${task_index}
else
    print "unsupported task type: ${task_type}"
    check_return 1
fi
print "Train Mode: task ${task_type} completed"

end_time=$(date +"%Y-%m-%d %H:%M:%S")

echo "[MYLOG]job end at ${end_time}"
