#!/bin/bash

# source ~/.bashrc

# config
model_dir="./model"
train_data="./t_td_lookalike_train_data_with_features_group_spark"
eval_data="./t_td_lookalike_train_data_with_features_group_spark"
config_model_type="deep"

feature_size=10000

begin_time=$(date +"%Y-%m-%d %H:%M:%S")
echo "[MYLOG]job begin at ${begin_time}..."

export HADOOP_USER_NAME="xpguo"
export CLASSPATH=$CLASSPATH:$(${HADOOP_HDFS_HOME}/bin/hadoop classpath --glob)

function run_task() {
    echo "run task begin..."
    python MWdnn.py \
        --run_mode "local" \
        --job_type "train_and_eval" \
        --model_type "${config_model_type}" \
        --model_dir "${model_dir}" \
        --feature_size ${feature_size} \
        --cold_start False \
        --train_data  "${train_data}" \
        --eval_data  "${eval_data}" \
    echo "run task finished"

    local ret=$?
    return ${ret}
}

run_task

end_time=$(date +"%Y-%m-%d %H:%M:%S")
echo "[MYLOG]job end at ${end_time}"
